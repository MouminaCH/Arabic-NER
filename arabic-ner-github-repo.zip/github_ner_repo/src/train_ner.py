
# Cleaned script generated from Kaggle notebook: finetune-all (1).ipynb
# Notes:
# - Fixed glued commands (e.g., '!pip ...from transformers')
# - Replaced eval_strategy with evaluation_strategy
# - Removed hard-coded HF tokens; use environment variable HF_TOKEN instead
# - You may still need to set DATA_DIR/OUT_DIR and verify dataset paths
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
from transformers import AutoTokenizer, AutoModelForTokenClassification, TrainingArguments, Trainer, DataCollatorForTokenClassification
from datasets import Dataset, DatasetDict
from seqeval.metrics import accuracy_score, f1_score
import numpy as np
from transformers import TrainingArguments
from sklearn.metrics import classification_report
import pandas as pd
import matplotlib.pyplot as plt
import torch
from transformers import pipeline
from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from collections import Counter
import re
from transformers import AutoTokenizer, AutoModelForTokenClassification

# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

 ''
# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list a ll fileslllunder the input directory

for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All"
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

!pip install transformers datasets seqeval -q



def read_conll_file(filepath):
    sentences = []
    labels = []
    with open(filepath, encoding="utf-8") as f:
        words = []
        tags = []
        for line in f:
            line = line.strip()
            if not line:
                if words:
                    sentences.append(words)
                    labels.append(tags)
                    words = []
                    tags = []
                continue
            splits = line.split()
            if len(splits) != 2:
                continue
            words.append(splits[0])
            tags.append(splits[1])
        if words:
            sentences.append(words)
            labels.append(tags)
    return sentences, labels

train_sentences, train_labels = read_conll_file("/kaggle/input/dataset-ner2025/train-c.txt")
val_sentences, val_labels = read_conll_file("/kaggle/input/dataset-ner2025/val-c.txt")
test_sentences, test_labels = read_conll_file("/kaggle/input/dataset-ner2025/test-c.txt")

train_data = Dataset.from_dict({"tokens": train_sentences, "ner_tags": train_labels})
test_data = Dataset.from_dict({"tokens": test_sentences, "ner_tags": test_labels})
val_data = Dataset.from_dict({"tokens": val_sentences, "ner_tags": val_labels})

dataset = DatasetDict({
    "train": train_data,
    "test": test_data,
    "val": val_data
})

model_checkpoint = "aubmindlab/bert-base-arabertv2"
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)

# Créer les mappings label <-> ID
unique_tags = sorted(list(set(tag for seq in train_labels for tag in seq)))
label2id = {tag: i for i, tag in enumerate(unique_tags)}
id2label = {i: tag for tag, i in label2id.items()}

def tokenize_and_align_labels(example):
    tokenized_inputs = tokenizer(example["tokens"], truncation=True, is_split_into_words=True)
    word_ids = tokenized_inputs.word_ids()

    previous_word_idx = None
    label_ids = []
    for word_idx in word_ids:
        if word_idx is None:
            label_ids.append(-100)
        elif word_idx != previous_word_idx:
            label_ids.append(label2id[example["ner_tags"][word_idx]])
        else:
            label_ids.append(-100)  # Ignorer les sous-tokens
        previous_word_idx = word_idx

    tokenized_inputs["labels"] = label_ids
    return tokenized_inputs

tokenized_dataset = dataset.map(tokenize_and_align_labels)

model = AutoModelForTokenClassification.from_pretrained(
    model_checkpoint,
    num_labels=len(label2id),
    id2label=id2label,
    label2id=label2id
)

!pip install -U transformers


HF_TOKEN = os.getenv('HF_TOKEN')

args = TrainingArguments(
    output_dir="./arabert-ner",
    learning_rate=2e-5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=10,
    weight_decay=0.01,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    report_to="tensorboard",
    logging_dir="./arabert-ner",
    logging_steps=250,
    save_steps=500,
    save_total_limit=2,
    load_best_model_at_end=True,
    push_to_hub=True,
    hub_token=TOKEN,
    hub_model_id="mouminach/moumi_ner_combined"
)

data_collator = DataCollatorForTokenClassification(tokenizer)

def compute_metrics(p):
    predictions, labels = p
    predictions = np.argmax(predictions, axis=-1)

    true_predictions = [
        [id2label[p] for (p, l) in zip(pred, lab) if l != -100]
        for pred, lab in zip(predictions, labels)
    ]
    true_labels = [
        [id2label[l] for (p, l) in zip(pred, lab) if l != -100]
        for pred, lab in zip(predictions, labels)
    ]

    return {
        "accuracy": accuracy_score(true_labels, true_predictions),
        "f1": f1_score(true_labels, true_predictions),
    }

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=tokenized_dataset["train"],
    eval_dataset=tokenized_dataset["val"],
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics,
)

trainer.train()

jnmhh


# Prédire sur le test set
predictions, labels, _ = trainer.predict(tokenized_dataset["test"])
predictions = np.argmax(predictions, axis=-1)

# Retirer les tokens spéciaux (-100)
true_predictions = [
    [id2label[p] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]
true_labels = [
    [id2label[l] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]

# Aplatir les listes
true_predictions = [item for sublist in true_predictions for item in sublist]
true_labels = [item for sublist in true_labels for item in sublist]

# Afficher rapport détaillé
print(classification_report(true_labels, true_predictions))


# Charger le fichier log généré par le Trainer
log_history = trainer.state.log_history

# Extraire les données utiles
metrics = [x for x in log_history if "eval_f1" in x]
epochs = [x["epoch"] for x in metrics]
f1s = [x["eval_f1"] for x in metrics]

# Tracer la courbe
plt.plot(epochs, f1s, marker='o', label="F1 Score")
plt.xlabel("Epoch")
plt.ylabel("F1 Score")
plt.title("F1 Score par Epoch")
plt.grid(True)
plt.legend()
plt.show()

model.save_pretrained("/kaggle/working/arabert-ner-model")
tokenizer.save_pretrained("/kaggle/working/arabert-ner-model")

trainer.push_to_hub()


# Créer le pipeline NER sans agrégation
ner_pipeline = pipeline("ner", model=model, tokenizer=tokenizer)

# Phrase de test
sentence = "ذهب محمد حمزة و خالد إلى البنك الوطني في تونس."

# Prédiction
results = ner_pipeline(sentence)

# Affichage des entités token par token
for entity in results:
    print(f"{entity['word']} ({entity['entity']}) - score: {entity['score']:.2f}")


# Créer le pipeline NER sans agrégation
ner_pipeline = pipeline("ner", model=model, tokenizer=tokenizer)

# Phrase de test
sentence = "ذهب محمد حمزة و خالد إلى البنك الوطني في تونس."

# Prédiction
results = ner_pipeline(sentence)

# Affichage des entités token par token
for entity in results:
    print(f"{entity['word']} ({entity['entity']}) - score: {entity['score']:.2f}")


model_path = "/kaggle/working/ner-model"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForTokenClassification.from_pretrained(model_path)

ner = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")

text = "ذهب محمد حمزة خالد إلى البنك الوطني في تونس."
results = ner(text)

# Affichage sans les "##"
for entity in results:
    word = entity['word'].replace("##", "")  # Supprimer les préfixes ## pour une lecture plus fluide
    print(f"{word} ({entity['entity']}) - score: {entity['score']:.2f}")


# Supposons que vous avez déjà ces deux listes après prédiction
# true_labels = [...]
# true_predictions = [...]

# Générer le rapport sous forme de dictionnaire
report = classification_report(true_labels, true_predictions, output_dict=True)

# Retirer les moyennes globales (accuracy, macro avg, weighted avg)
entity_labels = [label for label in report.keys() if label not in ['accuracy', 'macro avg', 'weighted avg']]

# Extraire les valeurs pour chaque entité
precisions = [report[label]['precision'] for label in entity_labels]
recalls = [report[label]['recall'] for label in entity_labels]
f1_scores = [report[label]['f1-score'] for label in entity_labels]

x = np.arange(len(entity_labels))  # Les positions des entités sur l'axe X
width = 0.25  # Largeur des barres

# Créer le diagramme
plt.figure(figsize=(12, 6))
plt.bar(x - width, precisions, width, label='Precision')
plt.bar(x, recalls, width, label='Recall')
plt.bar(x + width, f1_scores, width, label='F1-score')

# Ajouter des détails
plt.xlabel('Entities')
plt.ylabel('Scores')
plt.title('Evaluation par entité (Precision, Recall, F1-score)')
plt.xticks(x, entity_labels, rotation=45)
plt.ylim(0, 1.05)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()

# Afficher le diagramme
plt.show()


# Supposons que vous avez déjà ces deux listes :
# true_labels = [...]
# true_predictions = [...]

# Générer le rapport de classification sous forme de dictionnaire
report = classification_report(true_labels, true_predictions, output_dict=True)

# Garder uniquement les vraies classes (pas les moyennes)
entity_labels = [label for label in report if label not in ['accuracy', 'macro avg', 'weighted avg']]

# Extraire les F1-scores
f1_scores = [report[label]['f1-score'] for label in entity_labels]

# Tracer le diagramme
plt.figure(figsize=(10, 5))
plt.bar(entity_labels, f1_scores, color='skyblue')
plt.xlabel('Entités nommées')
plt.ylabel('F1-score')
plt.title('F1-score par entité')
plt.ylim(0, 1.05)
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Afficher
plt.show()


# Supposons que ces listes existent déjà et sont plates :
# true_labels = [...]
# true_predictions = [...]

# Si nécessaire, tu peux récupérer la liste unique des labels :
labels = sorted(list(set(true_labels + true_predictions)))

# Calculer la matrice de confusion
cm = confusion_matrix(true_labels, true_predictions, labels=labels)

# Affichage avec légende
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
plt.figure(figsize=(12, 12))
disp.plot(include_values=True, cmap='Blues', xticks_rotation='vertical')
plt.title("Matrice de confusion pour la NER")
plt.show()


# Supposons que tu as déjà ces deux listes à plat :
# true_labels et true_predictions contiennent les labels (ex : "B-PERS", "I-LOC", etc.)
# Tu les as obtenus comme ceci (exemple) :
# true_predictions = [...]
# true_labels = [...]

# Filtrer les "O"
filtered_true = []
filtered_pred = []

for t, p in zip(true_labels, true_predictions):
    if t != "O":  # On ignore les lignes avec vrai label = "O"
        filtered_true.append(t)
        filtered_pred.append(p)

# Créer liste de labels sans "O"
labels = sorted(set(filtered_true + filtered_pred) - {"O"})

# Calcul de la matrice de confusion
cm = confusion_matrix(filtered_true, filtered_pred, labels=labels)

# Affichage
fig, ax = plt.subplots(figsize=(6, 4))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(ax=ax, cmap="Blues", xticks_rotation=45, values_format='d')
plt.title("Matrice de confusion (sans 'O')")
plt.show()


def compter_entites_par_type(fichier):
    with open(fichier, 'r', encoding='utf-8') as f:
        lignes = f.readlines()

    compteur = Counter()

    for ligne in lignes:
        ligne = ligne.strip()
        if not ligne:
            continue  # ignorer les lignes vides
        parts = ligne.split()
        if len(parts) != 2:
            continue  # ignorer les lignes mal formatées
        mot, etiquette = parts

        if etiquette.startswith("B-"):
            type_entite = etiquette[2:]
            compteur[type_entite] += 1

    return compteur

# Exemple d'utilisation
fichier_entree = "/kaggle/input/wdc-moumi/WDC.txt"
stats = compter_entites_par_type(fichier_entree)

# Affichage trié par nombre décroissant
for type_entite, nombre in stats.most_common():
    print(f"{type_entite}: {nombre}")

def process_anercorp(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as infile, \
         open(output_file, 'w', encoding='utf-8') as outfile:

        for line in infile:
            line = line.strip()

            if not line:
                outfile.write('\n')
                continue

            parts = line.split()
            if len(parts) < 2:
                outfile.write(line + '\n')
                continue

            token, tag = parts[0], parts[-1]

            # Convertir MISC → O
            if tag in ['B-MISC', 'I-MISC']:
                tag = 'O'

            # Renommer PER → PERS
            if tag.startswith('B-PER'):
                tag = 'B-PERS'
            elif tag.startswith('I-PER'):
                tag = 'I-PERS'

            outfile.write(f"{token} {tag}\n")

            # Ajouter une ligne vide après ". O"
            if token == '.' and tag == 'O':
                outfile.write('\n')

    print("✅ Traitement terminé. Fichier nettoyé écrit dans :", output_file)


# Exemple d'utilisation
if __name__ == "__main__":
    input_path = "/kaggle/input/wdc-moumi/WDC.txt"  # Fichier d'entrée
    output_path = "wdc.txt"                # Fichier de sortie
    process_anercorp(input_path, output_path)


def compter_entites_par_type(fichier):
    with open(fichier, 'r', encoding='utf-8') as f:
        lignes = f.readlines()

    compteur = Counter()

    for ligne in lignes:
        ligne = ligne.strip()
        if not ligne:
            continue  # ignorer les lignes vides
        parts = ligne.split()
        if len(parts) != 2:
            continue  # ignorer les lignes mal formatées
        mot, etiquette = parts

        if etiquette.startswith("B-"):
            type_entite = etiquette[2:]
            compteur[type_entite] += 1

    return compteur

# Exemple d'utilisation
fichier_entree = "/kaggle/working/wdc.txt"
stats = compter_entites_par_type(fichier_entree)

# Affichage trié par nombre décroissant
for type_entite, nombre in stats.most_common():
    print(f"{type_entite}: {nombre}")

def insert_empty_after_dot_o(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as infile, \
         open(output_file, 'w', encoding='utf-8') as outfile:

        for line in infile:
            stripped = line.strip()
            outfile.write(line)
            if stripped.lower() == '. o':
                outfile.write('\n')  # Ajoute une ligne vide après ". O"

    print("✅ Les lignes vides ont été insérées après '. O' dans :", output_file)


# Exemple d’utilisation
if __name__ == "__main__":
    input_path = "/kaggle/working/wdc.txt"
    output_path = "/kaggle/working/wdc1.txt"
    insert_empty_after_dot_o(input_path, output_path)


def compter_entites_par_type(fichier):
    with open(fichier, 'r', encoding='utf-8') as f:
        lignes = f.readlines()

    compteur = Counter()

    for ligne in lignes:
        ligne = ligne.strip()
        if not ligne:
            continue  # ignorer les lignes vides
        parts = ligne.split()
        if len(parts) != 2:
            continue  # ignorer les lignes mal formatées
        mot, etiquette = parts

        if etiquette.startswith("B-"):
            type_entite = etiquette[2:]
            compteur[type_entite] += 1

    return compteur

# Exemple d'utilisation
fichier_entree = "/kaggle/working/wdc1.txt"
stats = compter_entites_par_type(fichier_entree)

# Affichage trié par nombre décroissant
for type_entite, nombre in stats.most_common():
    print(f"{type_entite}: {nombre}")


def is_valid_tag(tag):
    if tag == 'O':
        return True
    return re.match(r'^[BI]-(PERS|LOC|ORG)$', tag) is not None

def clean_bio_file(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as infile, \
         open(output_file, 'w', encoding='utf-8') as outfile:

        for line in infile:
            stripped = line.strip()

            if not stripped:
                outfile.write('\n')
                continue

            parts = stripped.split()
            if len(parts) < 2:
                continue  # ligne incomplète

            tag = parts[-1]

            if is_valid_tag(tag):
                outfile.write(line)
            else:
                continue  # ligne mal formée supprimée

    print(f"✅ Fichier nettoyé écrit dans : {output_file}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/working/wdc1.txt"          # Fichier source
    output_file = "/kaggle/working/wdc2.txt"  # Fichier nettoyé
    clean_bio_file(input_file, output_file)


def analyze_bio_file(file_path):
    entity_counter = Counter()
    empty_lines = 0
    o_count = 0

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()

            if line == '':
                empty_lines += 1
                continue

            parts = line.split()
            if len(parts) < 2:
                continue  # ligne mal formée

            tag = parts[-1]

            if tag == 'O':
                o_count += 1
            else:
                try:
                    _, label = tag.split('-', 1)
                    entity_counter[label] += 1
                except ValueError:
                    # Cas où le tag est mal formé (ex: juste un label sans B- ou I-)
                    entity_counter[tag] += 1

    # Affichage
    print("📊 Statistiques du fichier BIO :")
    print(f"- Lignes vides : {empty_lines}")
    print(f"- Occurrences de 'O' : {o_count}")
    print("- Occurrences par entité :")
    for entity, count in entity_counter.most_common():
        print(f"  {entity}: {count}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/working/wdc2.txt"  # Remplace par ton fichier BIO
    analyze_bio_file(input_file)


def analyze_bio_file(file_path):
    entity_counter = Counter()
    empty_lines = 0
    o_count = 0

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()

            if line == '':
                empty_lines += 1
                continue

            parts = line.split()
            if len(parts) < 2:
                continue  # ligne mal formée

            tag = parts[-1]

            if tag == 'O':
                o_count += 1
            else:
                try:
                    _, label = tag.split('-', 1)
                    entity_counter[label] += 1
                except ValueError:
                    # Cas où le tag est mal formé (ex: juste un label sans B- ou I-)
                    entity_counter[tag] += 1

    # Affichage
    print("📊 Statistiques du fichier BIO :")
    print(f"- Lignes vides : {empty_lines}")
    print(f"- Occurrences de 'O' : {o_count}")
    print("- Occurrences par entité :")
    for entity, count in entity_counter.most_common():
        print(f"  {entity}: {count}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/working/wdc2.txt"  # Remplace par ton fichier BIO
    analyze_bio_file(input_file)

def read_conll_file(filepath):
    sentences = []
    labels = []
    with open(filepath, encoding="utf-8") as f:
        words = []
        tags = []
        for line in f:
            line = line.strip()
            if not line:
                if words:
                    sentences.append(words)
                    labels.append(tags)
                    words = []
                    tags = []
                continue
            splits = line.split()
            if len(splits) != 2:
                continue
            words.append(splits[0])
            tags.append(splits[1])
        if words:
            sentences.append(words)
            labels.append(tags)
    return sentences, labels

train_sentences, train_labels = read_conll_file("/kaggle/input/dataset-ner2025/train-c.txt")
val_sentences, val_labels = read_conll_file("/kaggle/input/dataset-ner2025/val-c.txt")
test_sentences, test_labels = read_conll_file("/kaggle/working/wdc2.txt")

train_data = Dataset.from_dict({"tokens": train_sentences, "ner_tags": train_labels})
test_data = Dataset.from_dict({"tokens": test_sentences, "ner_tags": test_labels})
val_data = Dataset.from_dict({"tokens": val_sentences, "ner_tags": val_labels})

dataset = DatasetDict({
    "train": train_data,
    "test": test_data,
    "val": val_data
})

model_checkpoint = "mouminach/moumi_ner_combined"
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)

# Créer les mappings label <-> ID
unique_tags = sorted(list(set(tag for seq in train_labels for tag in seq)))
label2id = {tag: i for i, tag in enumerate(unique_tags)}
id2label = {i: tag for tag, i in label2id.items()}

def tokenize_and_align_labels(example):
    tokenized_inputs = tokenizer(example["tokens"], truncation=True, is_split_into_words=True)
    word_ids = tokenized_inputs.word_ids()

    previous_word_idx = None
    label_ids = []
    for word_idx in word_ids:
        if word_idx is None:
            label_ids.append(-100)
        elif word_idx != previous_word_idx:
            label_ids.append(label2id[example["ner_tags"][word_idx]])
        else:
            label_ids.append(-100)  # Ignorer les sous-tokens
        previous_word_idx = word_idx

    tokenized_inputs["labels"] = label_ids
    return tokenized_inputs

tokenized_dataset = dataset.map(tokenize_and_align_labels)

model = AutoModelForTokenClassification.from_pretrained(
    model_checkpoint,
    num_labels=len(label2id),
    id2label=id2label,
    label2id=label2id
)


# Prédire sur le test set
predictions, labels, _ = trainer.predict(tokenized_dataset["test"])
predictions = np.argmax(predictions, axis=-1)

# Retirer les tokens spéciaux (-100)
true_predictions = [
    [id2label[p] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]
true_labels = [
    [id2label[l] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]

# Aplatir les listes
true_predictions = [item for sublist in true_predictions for item in sublist]
true_labels = [item for sublist in true_labels for item in sublist]

# Afficher rapport détaillé
print(classification_report(true_labels, true_predictions))


# Supposons que tu as déjà ces deux listes à plat :
# true_labels et true_predictions contiennent les labels (ex : "B-PERS", "I-LOC", etc.)
# Tu les as obtenus comme ceci (exemple) :
# true_predictions = [...]
# true_labels = [...]

# Filtrer les "O"
filtered_true = []
filtered_pred = []

for t, p in zip(true_labels, true_predictions):
    if t != "O":  # On ignore les lignes avec vrai label = "O"
        filtered_true.append(t)
        filtered_pred.append(p)

# Créer liste de labels sans "O"
labels = sorted(set(filtered_true + filtered_pred) - {"O"})

# Calcul de la matrice de confusion
cm = confusion_matrix(filtered_true, filtered_pred, labels=labels)

# Affichage
fig, ax = plt.subplots(figsize=(6, 4))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(ax=ax, cmap="Blues", xticks_rotation=45, values_format='d')
plt.title("Matrice de confusion (sans 'O')")
plt.show()


# Supposons que vous avez déjà ces deux listes après prédiction
# true_labels = [...]
# true_predictions = [...]

# Générer le rapport sous forme de dictionnaire
report = classification_report(true_labels, true_predictions, output_dict=True)

# Retirer les moyennes globales (accuracy, macro avg, weighted avg)
entity_labels = [label for label in report.keys() if label not in ['accuracy', 'macro avg', 'weighted avg']]

# Extraire les valeurs pour chaque entité
precisions = [report[label]['precision'] for label in entity_labels]
recalls = [report[label]['recall'] for label in entity_labels]
f1_scores = [report[label]['f1-score'] for label in entity_labels]

x = np.arange(len(entity_labels))  # Les positions des entités sur l'axe X
width = 0.25  # Largeur des barres

# Créer le diagramme
plt.figure(figsize=(12, 6))
plt.bar(x - width, precisions, width, label='Precision')
plt.bar(x, recalls, width, label='Recall')
plt.bar(x + width, f1_scores, width, label='F1-score')

# Ajouter des détails
plt.xlabel('Entities')
plt.ylabel('Scores')
plt.title('Evaluation par entité (Precision, Recall, F1-score)')
plt.xticks(x, entity_labels, rotation=45)
plt.ylim(0, 1.05)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()

# Afficher le diagramme
plt.show()

def read_conll_file(filepath):
    sentences = []
    labels = []
    with open(filepath, encoding="utf-8") as f:
        words = []
        tags = []
        for line in f:
            line = line.strip()
            if not line:
                if words:
                    sentences.append(words)
                    labels.append(tags)
                    words = []
                    tags = []
                continue
            splits = line.split()
            if len(splits) != 2:
                continue
            words.append(splits[0])
            tags.append(splits[1])
        if words:
            sentences.append(words)
            labels.append(tags)
    return sentences, labels

train_sentences, train_labels = read_conll_file("/kaggle/input/dataset-ner2025/train-c.txt")
val_sentences, val_labels = read_conll_file("/kaggle/input/dataset-ner2025/val-c.txt")
test_sentences, test_labels = read_conll_file("/kaggle/input/tweets/TWEETS-TRAIN.txt")

train_data = Dataset.from_dict({"tokens": train_sentences, "ner_tags": train_labels})
test_data = Dataset.from_dict({"tokens": test_sentences, "ner_tags": test_labels})
val_data = Dataset.from_dict({"tokens": val_sentences, "ner_tags": val_labels})

dataset = DatasetDict({
    "train": train_data,
    "test": test_data,
    "val": val_data
})

model_checkpoint = "mouminach/moumi_ner_combined"
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)

# Créer les mappings label <-> ID
unique_tags = sorted(list(set(tag for seq in train_labels for tag in seq)))
label2id = {tag: i for i, tag in enumerate(unique_tags)}
id2label = {i: tag for tag, i in label2id.items()}


def analyze_bio_file(file_path):
    entity_counter = Counter()
    empty_lines = 0
    o_count = 0

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()

            if line == '':
                empty_lines += 1
                continue

            parts = line.split()
            if len(parts) < 2:
                continue  # ligne mal formée

            tag = parts[-1]

            if tag == 'O':
                o_count += 1
            else:
                try:
                    _, label = tag.split('-', 1)
                    entity_counter[label] += 1
                except ValueError:
                    # Cas où le tag est mal formé (ex: juste un label sans B- ou I-)
                    entity_counter[tag] += 1

    # Affichage
    print("📊 Statistiques du fichier BIO :")
    print(f"- Lignes vides : {empty_lines}")
    print(f"- Occurrences de 'O' : {o_count}")
    print("- Occurrences par entité :")
    for entity, count in entity_counter.most_common():
        print(f"  {entity}: {count}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/input/tweets/TWEETS-TRAIN.txt"  # Remplace par ton fichier BIO
    analyze_bio_file(input_file)


def is_valid_tag(tag):
    if tag == 'O':
        return True
    return re.match(r'^[BI]-(PERS|LOC|ORG)$', tag) is not None

def clean_bio_file(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as infile, \
         open(output_file, 'w', encoding='utf-8') as outfile:

        for line in infile:
            stripped = line.strip()

            if not stripped:
                outfile.write('\n')
                continue

            parts = stripped.split()
            if len(parts) < 2:
                continue  # ligne incomplète

            tag = parts[-1]

            if is_valid_tag(tag):
                outfile.write(line)
            else:
                continue  # ligne mal formée supprimée

    print(f"✅ Fichier nettoyé écrit dans : {output_file}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/input/tweets/TWEETS-TRAIN.txt"          # Fichier source
    output_file = "/kaggle/working/tweets.txt"  # Fichier nettoyé
    clean_bio_file(input_file, output_file)


def analyze_bio_file(file_path):
    entity_counter = Counter()
    empty_lines = 0
    o_count = 0

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()

            if line == '':
                empty_lines += 1
                continue

            parts = line.split()
            if len(parts) < 2:
                continue  # ligne mal formée

            tag = parts[-1]

            if tag == 'O':
                o_count += 1
            else:
                try:
                    _, label = tag.split('-', 1)
                    entity_counter[label] += 1
                except ValueError:
                    # Cas où le tag est mal formé (ex: juste un label sans B- ou I-)
                    entity_counter[tag] += 1

    # Affichage
    print("📊 Statistiques du fichier BIO :")
    print(f"- Lignes vides : {empty_lines}")
    print(f"- Occurrences de 'O' : {o_count}")
    print("- Occurrences par entité :")
    for entity, count in entity_counter.most_common():
        print(f"  {entity}: {count}")


# Exemple d'utilisation
if __name__ == "__main__":
    input_file = "/kaggle/working/tweets.txt"  # Remplace par ton fichier BIO
    analyze_bio_file(input_file)

def read_conll_file(filepath):
    sentences = []
    labels = []
    with open(filepath, encoding="utf-8") as f:
        words = []
        tags = []
        for line in f:
            line = line.strip()
            if not line:
                if words:
                    sentences.append(words)
                    labels.append(tags)
                    words = []
                    tags = []
                continue
            splits = line.split()
            if len(splits) != 2:
                continue
            words.append(splits[0])
            tags.append(splits[1])
        if words:
            sentences.append(words)
            labels.append(tags)
    return sentences, labels

train_sentences, train_labels = read_conll_file("/kaggle/input/dataset-ner2025/train-c.txt")
val_sentences, val_labels = read_conll_file("/kaggle/input/dataset-ner2025/val-c.txt")
test_sentences, test_labels = read_conll_file("/kaggle/working/tweets.txt")

train_data = Dataset.from_dict({"tokens": train_sentences, "ner_tags": train_labels})
test_data = Dataset.from_dict({"tokens": test_sentences, "ner_tags": test_labels})
val_data = Dataset.from_dict({"tokens": val_sentences, "ner_tags": val_labels})

dataset = DatasetDict({
    "train": train_data,
    "test": test_data,
    "val": val_data
})

model_checkpoint = "mouminach/moumi_ner_combined"
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)

# Créer les mappings label <-> ID
unique_tags = sorted(list(set(tag for seq in train_labels for tag in seq)))
label2id = {tag: i for i, tag in enumerate(unique_tags)}
id2label = {i: tag for tag, i in label2id.items()}

def tokenize_and_align_labels(example):
    tokenized_inputs = tokenizer(example["tokens"], truncation=True, is_split_into_words=True)
    word_ids = tokenized_inputs.word_ids()

    previous_word_idx = None
    label_ids = []
    for word_idx in word_ids:
        if word_idx is None:
            label_ids.append(-100)
        elif word_idx != previous_word_idx:
            label_ids.append(label2id[example["ner_tags"][word_idx]])
        else:
            label_ids.append(-100)  # Ignorer les sous-tokens
        previous_word_idx = word_idx

    tokenized_inputs["labels"] = label_ids
    return tokenized_inputs

tokenized_dataset = dataset.map(tokenize_and_align_labels)

model = AutoModelForTokenClassification.from_pretrained(
    model_checkpoint,
    num_labels=len(label2id),
    id2label=id2label,
    label2id=label2id
)


# Prédire sur le test set
predictions, labels, _ = trainer.predict(tokenized_dataset["test"])
predictions = np.argmax(predictions, axis=-1)

# Retirer les tokens spéciaux (-100)
true_predictions = [
    [id2label[p] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]
true_labels = [
    [id2label[l] for (p, l) in zip(pred, lab) if l != -100]
    for pred, lab in zip(predictions, labels)
]

# Aplatir les listes
true_predictions = [item for sublist in true_predictions for item in sublist]
true_labels = [item for sublist in true_labels for item in sublist]

# Afficher rapport détaillé
print(classification_report(true_labels, true_predictions))


# Supposons que tu as déjà ces deux listes à plat :
# true_labels et true_predictions contiennent les labels (ex : "B-PERS", "I-LOC", etc.)
# Tu les as obtenus comme ceci (exemple) :
# true_predictions = [...]
# true_labels = [...]

# Filtrer les "O"
filtered_true = []
filtered_pred = []

for t, p in zip(true_labels, true_predictions):
    if t != "O":  # On ignore les lignes avec vrai label = "O"
        filtered_true.append(t)
        filtered_pred.append(p)

# Créer liste de labels sans "O"
labels = sorted(set(filtered_true + filtered_pred) - {"O"})

# Calcul de la matrice de confusion
cm = confusion_matrix(filtered_true, filtered_pred, labels=labels)

# Affichage
fig, ax = plt.subplots(figsize=(6, 4))
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
disp.plot(ax=ax, cmap="Blues", xticks_rotation=45, values_format='d')
plt.title("Matrice de confusion (sans 'O')")
plt.show()


# Supposons que vous avez déjà ces deux listes après prédiction
# true_labels = [...]
# true_predictions = [...]

# Générer le rapport sous forme de dictionnaire
report = classification_report(true_labels, true_predictions, output_dict=True)

# Retirer les moyennes globales (accuracy, macro avg, weighted avg)
entity_labels = [label for label in report.keys() if label not in ['accuracy', 'macro avg', 'weighted avg']]

# Extraire les valeurs pour chaque entité
precisions = [report[label]['precision'] for label in entity_labels]
recalls = [report[label]['recall'] for label in entity_labels]
f1_scores = [report[label]['f1-score'] for label in entity_labels]

x = np.arange(len(entity_labels))  # Les positions des entités sur l'axe X
width = 0.25  # Largeur des barres

# Créer le diagramme
plt.figure(figsize=(12, 6))
plt.bar(x - width, precisions, width, label='Precision')
plt.bar(x, recalls, width, label='Recall')
plt.bar(x + width, f1_scores, width, label='F1-score')

# Ajouter des détails
plt.xlabel('Entities')
plt.ylabel('Scores')
plt.title('Evaluation par entité (Precision, Recall, F1-score)')
plt.xticks(x, entity_labels, rotation=45)
plt.ylim(0, 1.05)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()

# Afficher le diagramme
plt.show()




# Spécifie le nouveau modèle NER
model_name = "Davlan/bert-base-multilingual-cased-ner-hrl"  # Exemple de modèle NER multilingue
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Définir le device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",  # Assurer que toutes les occurrences sont correctement converties
    "B-PERS": "B-PER",
    # Ajouter d'autres conversions si nécessaire
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/input/dataset-ner2025/test-c.txt"  # chemin à adapter
    sentences = load_data(test_path)

    # Labels du modèle Davlan (exemple – adapte si besoin)
    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


# Spécifie le nouveau modèle NER
model_name = "Davlan/bert-base-multilingual-cased-ner-hrl"  # Exemple de modèle NER multilingue
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Définir le device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",  # Assurer que toutes les occurrences sont correctement converties
    "B-PERS": "B-PER",
    # Ajouter d'autres conversions si nécessaire
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/working/tweets.txt"  # chemin à adapter
    sentences = load_data(test_path)

    # Labels du modèle Davlan (exemple – adapte si besoin)
    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


# Spécifie le nouveau modèle NER
model_name = "Davlan/bert-base-multilingual-cased-ner-hrl"  # Exemple de modèle NER multilingue
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Définir le device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",  # Assurer que toutes les occurrences sont correctement converties
    "B-PERS": "B-PER",
    # Ajouter d'autres conversions si nécessaire
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/working/wdc2.txt"  # chemin à adapter
    sentences = load_data(test_path)

    # Labels du modèle Davlan (exemple – adapte si besoin)
    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


model_name = "abdusah/arabert-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

# Définir le device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",  # Assurer que toutes les occurrences sont correctement converties
    "B-PERS": "B-PER",
    # Ajouter d'autres conversions si nécessaire
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/working/tweets.txt"  # chemin à adapter
    sentences = load_data(test_path)

    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


model_name = "abdusah/arabert-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/input/dataset-ner2025/test-c.txt"
    sentences = load_data(test_path)


    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


model_name = "abdusah/arabert-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True)
        word_ids = encoding.word_ids()  # Appel ici
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions
# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
}

# Fonction pour convertir les labels avant l'évaluation
def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Modifier la fonction d'évaluation pour utiliser la conversion
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    # Appliquer la conversion des labels
    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    # Vérification de la cohérence des longueurs
    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    # Afficher les classes prédites pour s'assurer qu'elles sont bien alignées
    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    # Spécifier explicitement les labels attendus
    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))




# Main
def main():
    test_path = "/kaggle/working/wdc2.txt"
    sentences = load_data(test_path)

    label2id = {
        "O": 0,
        "B-PERS": 1,
        "I-PERS": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()


model_name = "CAMeL-Lab/bert-base-arabic-camelbert-mix-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)

model = AutoModelForTokenClassification.from_pretrained(model_name)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True, max_length=512)
        # Ajout important
        word_ids = encoding.word_ids()
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions

label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-LOC": "I-LOC",
    "B-LOC": "B-LOC",
    "I-ORG": "I-ORG",
    "B-ORG": "B-ORG",
    "O": "O"
}

def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Évaluation
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))

# Main
def main():
    test_path = "/kaggle/working/wdc2.txt"
    sentences = load_data(test_path)

    label2id = {
        "O": 0,
        "B-PER": 1,
        "I-PER": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()



model_name = "CAMeL-Lab/bert-base-arabic-camelbert-mix-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)

model = AutoModelForTokenClassification.from_pretrained(model_name)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True, max_length=512)
        # Ajout important
        word_ids = encoding.word_ids()
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions

label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-LOC": "I-LOC",
    "B-LOC": "B-LOC",
    "I-ORG": "I-ORG",
    "B-ORG": "B-ORG",
    "O": "O"
}

def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Évaluation
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))

# Main
def main():
    test_path = "/kaggle/input/dataset-ner2025/test-c.txt"
    sentences = load_data(test_path)

    label2id = {
        "O": 0,
        "B-PER": 1,
        "I-PER": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()



model_name = "CAMeL-Lab/bert-base-arabic-camelbert-mix-ner"
tokenizer = AutoTokenizer.from_pretrained(model_name)

model = AutoModelForTokenClassification.from_pretrained(model_name)


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Chargement des données
def load_data(file_path):
    sentences = []
    sentence = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line == "":
                if sentence:
                    sentences.append(sentence)
                    sentence = []
            else:
                parts = line.split()
                if len(parts) == 2:
                    word, label = parts
                    sentence.append((word, label))
    if sentence:
        sentences.append(sentence)
    return sentences

# Prédiction
def predict_ner(model, tokenizer, sentences):
    model.eval()
    predictions = []
    true_labels = []

    for sentence in sentences:
        words = [w for w, l in sentence]
        labels = [l for w, l in sentence]

        encoding = tokenizer(words, is_split_into_words=True, return_tensors="pt", truncation=True, padding=True, max_length=512)
        # Ajout important
        word_ids = encoding.word_ids()
        encodings = {k: v.to(device) for k, v in encoding.items()}

        with torch.no_grad():
            outputs = model(**encodings)
            logits = outputs.logits
            preds = torch.argmax(logits, dim=-1).cpu().numpy()[0]

        pred_labels = []
        true_labels_sentence = []

        previous_word_idx = None
        for idx, word_idx in enumerate(word_ids):
            if word_idx is None or word_idx == previous_word_idx:
                continue
            pred_label = model.config.id2label[preds[idx]]
            pred_labels.append(pred_label)
            true_labels_sentence.append(labels[word_idx])
            previous_word_idx = word_idx

        predictions.append(pred_labels)
        true_labels.append(true_labels_sentence)

    return true_labels, predictions

# Dictionnaire de conversion des labels
label_conversion = {
    "I-PERS": "I-PER",
    "B-PERS": "B-PER",
    "I-LOC": "I-LOC",
    "B-LOC": "B-LOC",
    "I-ORG": "I-ORG",
    "B-ORG": "B-ORG",
    "O": "O"
}

def convert_labels(labels, label_conversion):
    return [label_conversion.get(label, label) for label in labels]

# Évaluation
def evaluate(true_labels, predictions, label2id):
    flattened_true_labels = [label for sublist in true_labels for label in sublist]
    flattened_predictions = [label for sublist in predictions for label in sublist]

    flattened_true_labels = convert_labels(flattened_true_labels, label_conversion)
    flattened_predictions = convert_labels(flattened_predictions, label_conversion)

    assert len(flattened_true_labels) == len(flattened_predictions), \
        f"Le nombre d'étiquettes réelles ({len(flattened_true_labels)}) et de prédictions ({len(flattened_predictions)}) ne correspond pas."

    print("Classes prédites par le modèle : ", set(flattened_predictions))
    print("Classes réelles : ", set(flattened_true_labels))

    labels = ['O', 'B-PER', 'I-PER', 'B-LOC', 'I-LOC', 'B-ORG', 'I-ORG']
    print(classification_report(flattened_true_labels, flattened_predictions, labels=labels, zero_division=1))

# Main
def main():
    test_path = "/kaggle/working/tweets.txt"  # à adapter selon votre fichier
    sentences = load_data(test_path)

    label2id = {
        "O": 0,
        "B-PER": 1,
        "I-PER": 2,
        "B-ORG": 3,
        "I-ORG": 4,
        "B-LOC": 5,
        "I-LOC": 6
    }

    true_labels, predictions = predict_ner(model, tokenizer, sentences)
    evaluate(true_labels, predictions, label2id)

if __name__ == "__main__":
    main()
