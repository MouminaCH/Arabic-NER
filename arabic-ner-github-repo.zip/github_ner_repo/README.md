# Arabic NER — AraBERT / CAMeL (Kaggle → GitHub)

Ce dépôt contient une version **propre et reproductible** de ton notebook Kaggle pour l’**étiquetage d’entités nommées (NER)** en arabe, basée sur Hugging Face Transformers.

## 🚀 Caractéristiques
- Tokenization et alignement BIO (`-100` pour sous-tokens)
- Entraînement via `Trainer` + `TrainingArguments`
- Métriques `seqeval` (F1, accuracy) + rapport `sklearn`
- Graphique F1/epoch et matrice de confusion (sans `O`)
- **Sans fuite de secrets** (HF_TOKEN à passer en variable d’environnement)
- Chemins **paramétrables** (`DATA_DIR`, `OUT_DIR`, `MODEL_NAME`)

## 📁 Arborescence
```
.
├── src/
│   └── train_ner.py          # Script principal (nettoyé du notebook Kaggle)
├── data/                     # Place ici train-c.txt, val-c.txt, test-c.txt (format CoNLL)
├── outputs/                  # Checkpoints / artefacts (ignorés par git)
├── notebooks/                # (optionnel) notebooks d'analyse/visualisation
├── requirements.txt
├── .gitignore
├── .env.example
├── LICENSE
└── README.md
```

## 🧩 Données attendues (format CoNLL)
Trois fichiers **UTF-8** avec une ligne vide entre phrases, une ligne par token :
```
Paris B-LOC
est O
belle O
. O

Samsung B-ORG
...

```
- `data/train-c.txt`
- `data/val-c.txt`
- `data/test-c.txt`

> Si tu unifies plusieurs corpus (ANERcorp / AQMAR / Wojood / WDC / Tweets), assure-toi d’avoir **un seul schéma de labels** (ex. `B-LOC`, `I-LOC`, `B-ORG`, `I-ORG`, `B-PERS`, `I-PERS`, `O`).

## 🛠️ Installation
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## ▶️ Entraîner
```bash
export DATA_DIR=./data
export OUT_DIR=./outputs
export MODEL_NAME=aubmindlab/bert-base-arabertv2  # ou un modèle HF perso
python src/train_ner.py
```

Le script :
- lit `DATA_DIR/train-c.txt`, `val-c.txt`, `test-c.txt`,
- entraîne un modèle NER,
- évalue sur `test` (rapport `classification_report`),
- enregistre modèle/tokenizer dans `outputs/model`,
- trace (si dispo) F1/epoch et matrice de confusion (sans `O`).

## ☁️ (Optionnel) Pousser sur Hugging Face Hub
1. Copie `.env.example` en `.env` et complète `HF_TOKEN` (ou exporte `HF_TOKEN` dans ton shell).
2. Active la publication :
```bash
export PUSH_TO_HUB=true
export HUB_MODEL_ID=your-username/arabic-ner-2025
python src/train_ner.py
```

## 🧪 Conseils
- Fixe `SEED` pour la reproductibilité.
- Évite de versionner des poids lourds → ils sont ignorés par `.gitignore`.
- Si tu veux évaluer plusieurs jeux de test, lance des runs séparés (ou adapte le script pour boucler proprement).

## 📜 Licence
Ce projet est sous licence **MIT** (voir `LICENSE`).

---

> Basé sur un notebook Kaggle nettoyé. Pour toute question ou amélioration, ouvre une *issue* ou propose une *PR*.
